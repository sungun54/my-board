package com.sbs.example.demo.controller;

// Controller
abstract public class Controller {
	public abstract void doAction(Request request);
}