package com.sbs.example.demo;
import java.sql.*;
import java.util.Map;

class Main {
	public static void main(String[] args) {
		App app = new App();
		app.start();
	}
}
